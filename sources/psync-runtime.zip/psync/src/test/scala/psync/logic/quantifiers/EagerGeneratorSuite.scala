package psync.logic.quantifiers

import psync.formula._
import psync.formula.Common._
import psync.logic._

import org.scalatest._

class EagerGeneratorSuite extends FunSuite {

  test("formula 1"){
    val axs = List(
      ForAll(List(p1), Eq(rp1, IntLit(0))),
      ForAll(List(p2), Eq(rp2, IntLit(0))),
      ForAll(List(p1,p2), Eq(pp1, pp2))
    )
    val itg = new EagerFormulaGenerator(axs, new CongruenceClosure)
    val g1 = itg.generate(p1)
    assert(g1.size == 2)
    assert(g1 contains Eq(IntLit(0), rp1))
    assert(g1 contains Eq(pp1, pp1))
    val g2 = itg.generate(p2)
    assert(g2.size == 3)
    assert(g2 contains Eq(IntLit(0), rp2))
    assert(g2.contains(Eq(pp2, pp1)) || g2.contains(Eq(pp1, pp2)))
    assert(g2 contains Eq(pp2, pp2))
    val g3 = itg.generate(p2)
    assert(g3.isEmpty)
  }

  test("formula 2"){
    val axs = And(
      ForAll(List(p1), Eq(rp1, IntLit(0))),
      ForAll(List(p2), Eq(rp2, IntLit(0))),
      ForAll(List(p1,p2), Eq(pp1, pp2))
    )
    val itg = new EagerGenerator(axs)
    val g1 = itg.generate(p1)
    assert(g1.size == 2)
    assert(g1 contains Eq(IntLit(0), rp1))
    assert(g1 contains Eq(pp1, pp1))
    val g2 = itg.generate(p2)
    assert(g2.size == 3)
    assert(g2 contains Eq(IntLit(0), rp2))
    assert(g2.contains(Eq(pp2, pp1)) || g2.contains(Eq(pp1, pp2)))
    assert(g2 contains Eq(pp2, pp2))
    val g3 = itg.generate(p2)
    assert(g3.isEmpty)
  }

  test("cc reduction"){
    val axs = And(
      Eq(p1, p2),
      ForAll(List(p1), Eq(rp1, IntLit(0))),
      ForAll(List(p1,p2), Eq(pp1, pp2))
    )
    val itg = new EagerGenerator(axs)
    val g1 = itg.generate(p1)
    assert(g1.size == 2)
    assert(g1.contains(Eq(IntLit(0), rp1)) || g1.contains(Eq(IntLit(0), rp2)))
    assert(g1.contains(Eq(pp1, pp1)) || g1.contains(Eq(pp2, pp2)))
    val g2 = itg.generate(p2)
    assert(g2.isEmpty)
  }

  test("clone") {
    val axs = And(
      ForAll(List(p1), Eq(rp1, IntLit(0))),
      ForAll(List(p2), Eq(rp2, IntLit(0))),
      ForAll(List(p1,p2), Eq(pp1, pp2))
    )
    val itg = new EagerGenerator(axs)
    val g1 = itg.generate(p1)
    assert(g1.size == 2)
    assert(g1 contains Eq(IntLit(0), rp1))
    assert(g1 contains Eq(pp1, pp1))
    val itg2 = itg.clone
    val g2 = itg.generate(p2)
    assert(g2.size == 3)
    assert(g2 contains Eq(IntLit(0), rp2))
    assert(g2.contains(Eq(pp2, pp1)) || g2.contains(Eq(pp1, pp2)))
    assert(g2 contains Eq(pp2, pp2))
    val g3 = itg.generate(p2)
    assert(g3.isEmpty)
    val g4 = itg2.generate(p2)
    assert(g4.size == 3)
    assert(g4 contains Eq(IntLit(0), rp2))
    assert(g4.contains(Eq(pp2, pp1)) || g4.contains(Eq(pp1, pp2)))
    assert(g4 contains Eq(pp2, pp2))
    val g5 = itg2.generate(p2)
    assert(g5.isEmpty)
  }

  test("compdef caching"){
    val s = Variable("s").setType(FSet(pid))
    val axs = And(
      ForAll(List(p1,p2),
        Exists(List(s),
          And(
            Eq(s, Comprehension(List(p2), Eq(p1, p2))),
            Eq(p1,p2)
          )
        )
      )
    )
    val itg = new EagerGenerator(axs)
    val g1 = itg.generate(Set[Formula](p1,p2))
    assert(g1.size == 4)
  }

}
