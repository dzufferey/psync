package round.utils

import dzufferey.arg._
import dzufferey.utils.Logger
import dzufferey.utils.LogLevel._

/** default configuration object */
abstract class DefaultOptions extends Options {

  //verbosity
  newOption("-v", Unit(() => Logger.moreVerbose), "increase the verbosity level.")
  newOption("-q", Unit(() => Logger.lessVerbose), "decrease the verbosity level.")
  newOption("--hide", String( str => Logger.disallow(str)), "hide the output with given prefix.")
 
}

object Options extends DefaultOptions {
  
  //general reporting option
  var report = false
  var reportOutput: Option[java.lang.String] = None
  var stats = false
 
  newOption("-r", Unit(() => report = true), "output a report (with a default name).")
  newOption("--report", String(str => { report = true; reportOutput = Some(str) } ), "output a report with given name.")
  newOption("--stats", Unit(() => stats = true), "print statistics about the execution.")
 
  var dumpVcs = false

  newOption("--smtSolver", String(str => smtlib.Solver.setCmd(str.split(" "))), "The smt sovler (+ options) to use (default: \"z3 -smt2 -in\").")
  newOption("--dumpVcs", Unit( () => dumpVcs = true ), "dump the SMT queries into files.")
 
  val usage = "..."

 
}
