package round.formula

import dzufferey.utils.Namer

object Simplify {

  //removes functions that can be expressed in terms of other
  def normalize(f: Formula) = normalizer.transform(f)
  private val normalizer = new Mapper(normalizef)
  private def normalizef(f: Formula): Formula = f match {
    case Implies(List(a,b)) => Copier.Application(f, Or, List(Copier.Application(a, Not, List(a)),b))
    case Neq(List(a,b)) => Copier.Application(f, Not, List(Copier.Application(f, Eq, List(a,b))))
    case Geq(List(a,b)) => Copier.Application(f, Not, List(Copier.Application(f, Lt, List(b,a))))
    case Leq(List(a,b)) => Copier.Application(f, Not, List(Copier.Application(f, Lt, List(b,a))))
    case Gt(List(a,b)) =>  Copier.Application(f, Lt, List(b,a))
    case SupersetEq(List(a,b)) => Copier.Application(f, SubsetEq, List(b,a))
    case Contains(List(a,b)) => Copier.Application(f, In, List(b,a))
    case IsEmpty(List(a)) => Copier.Application(f, Not, List(Copier.Application(f, IsDefined, List(a))))
    case other => other
  }


  //negation normal form (assumes normalized formula)
  //TODO also recurse in Comprehension
  def nnf(f: Formula, neg: Boolean = false): Formula = f match {
    case Binding(ForAll, vs, f2) =>
      val bt = if (neg) Exists else ForAll
      Copier.Binding(f, bt, vs, nnf(f2, neg))
    case Binding(Exists, vs, f2) =>
      val bt = if (neg) ForAll else Exists
      Copier.Binding(f, bt, vs, nnf(f2, neg))
    case Application(Not, List(f2)) =>
      nnf(f2, !neg)
    case Application(And, args) => 
      val fct = if (neg) Or else And
      val args2 = args.map(nnf(_, neg))
      Copier.Application(f, fct, args2)
    case Application(Or, args) => 
      val fct = if (neg) And else Or
      val args2 = args.map(nnf(_, neg))
      Copier.Application(f, fct, args2)
    case other =>
      assert(other.tpe == Bool)
      if (neg) Not(other) else other
  }

  def cnf(f: Formula): Formula = {
    ???
  }
  
  def dnf(f: Formula): Formula = {
    ???
  }
  

  //prenex normal form
  //TODO also recurse in Comprehension
  def pnf(f: Formula) = {
    val f2 = boundVarUnique(nnf(f))
    def merge(lst: List[List[(BindingType, List[Variable])]], exists: Boolean): List[(BindingType, List[Variable])] = {
      val (vs, rest) = lst.foldLeft( (List[Variable](), List[List[(BindingType, List[Variable])]]()) )( (acc, f) => {
        f match {
          case (ForAll, vs) :: xs => if (!exists) (vs ::: acc._1, xs :: acc._2) else (acc._1, f :: acc._2)
          case (Exists, vs) :: xs => if ( exists) (vs ::: acc._1, xs :: acc._2) else (acc._1, f :: acc._2)
          case Nil => acc
          case _ => sys.error("should not happen")
        }
      })
      val suffix = if (!rest.isEmpty) merge(rest, !exists) else Nil
      if (vs.isEmpty) suffix
      else if (exists) (Exists, vs) :: suffix
      else (ForAll, vs) :: suffix
    }
    def pull(f: Formula, exists: Boolean): (List[(BindingType, List[Variable])], Formula) = f match {
      case Binding(ForAll, vs, f2) =>
        val (b1, f3) = pull(f2, false)
        val b2 = b1 match {
          case (ForAll, vs2) :: bs => (ForAll, vs ::: vs2) :: bs
          case _ => (ForAll, vs) :: b1 
        }
        (b2, f3)

      case Binding(Exists, vs, f2) =>
        val (b1, f3) = pull(f2, true)
        val b2 = b1 match {
          case (Exists, vs2) :: bs => (Exists, vs ::: vs2) :: bs
          case _ => (Exists, vs) :: b1 
        }
        (b2, f3)

      case Application(And, args) => 
        val (binders, args2) = args.map(pull(_, exists)).unzip
        val merged = merge(binders, exists)
        val f2 = Copier.Application(f, And, args2)
        (merged, f2)

      case Application(Or, args) => 
        val (binders, args2) = args.map(pull(_, exists)).unzip
        val merged = merge(binders, exists)
        val f2 = Copier.Application(f, Or, args2)
        (merged, f2)

      case other =>
        (Nil, other)
    }
    val (quantifiers, qf) = pull(f2, true)
    FormulaUtils.restoreQuantifierPrefix(quantifiers, qf)
  }

  def isPnf(f: Formula): Boolean = {
    def rmQ(f: Formula): Formula = f match {
      case Binding(ForAll | Exists, _, f) => rmQ(f)
      case f => f
    }
    def hasQ(f: Formula): Boolean = f match {
      case Binding(ForAll | Exists, _, _) => true
      case Application(_, args) => args.exists(hasQ)
      case _ => false
    }
    !hasQ(rmQ(f))
  }

  /** try to push the quantifiers as low as possible. */
  def reversePnf(f: Formula): Formula = {
    ???
  }

  //makes all the bound variables different
  def boundVarUnique(f: Formula): Formula = {
    def s(subst: Map[String, String], v: Variable): Variable = {
      if (subst contains v.name) Copier.Variable(v, subst(v.name))
      else v
    }
    def process(f: Formula, used: Set[String], subst: Map[String, String]): (Formula, Set[String]) = f match {
      case Binding(bt, vs, f2) =>
        val masking = vs.filter(v => used(v.name))
        val newSubst = masking.map( v => (v.name, Namer(v.name)) )
        //println("boundVarUnique, renamings: " + newSubst)
        val subst2 = subst ++ newSubst
        val vs2 = vs.map(s(subst2,_))
        val used2 = vs2.foldLeft(used)(_ + _.name)
        val (f3, used3) = process(f2, used2, subst2)
        (Copier.Binding(f, bt, vs2, f3), used3)
      case Application(fct, args) => 
        val (args2, used2) = args.foldRight( (List[Formula](), used) )( (arg, acc) => {
          val (args, used) = acc
          val (arg2, used2) = process(arg, used, subst)
          (arg2 :: args, used2)
        }) 
        (Copier.Application(f, fct, args2), used2)
      case v @ Variable(_) => (s(subst, v), used)
      case other => (other, used)
    }
    process(f,
            Set.empty[String],
            Map.empty[String, String])._1
  }

  def simplifySet(f: Formula): Formula = {
    //TODO
    ???
  }
  
  def lcm(m: scala.Int, n: scala.Int) = {
    var a = m
    var b = n
    while (a != b) {
      if (a < b) a += m
      else       b += n
    }
    a
  }
  
  def simplifyQuantifiers(f: Formula): Formula = {
    def fct(formula: Formula) = formula match {
      case ForAll(vs, f) =>
        val free = f.freeVariables
        val vs2 = vs.filter(free contains _)
        if (vs2.isEmpty) f else ForAll(vs2, f)
      case Exists(vs, f) =>
        val free = f.freeVariables
        val vs2 = vs.filter(free contains _)
        if (vs2.isEmpty) f else Exists(vs2, f)
      case other => other 
    }
    FormulaUtils.map(fct, f)
  }
  
  def simplifyInt(f: Formula): Formula = {
    //division: from 'x > 2n/3' to '3x > 2n'
    def getDenom(f: Formula): scala.Int = f match {
      case Plus(lst) => lst.foldLeft(1)( (acc, f) => lcm(acc, getDenom(f)) )
      case Minus(lst) => lst.foldLeft(1)( (acc, f) => lcm(acc, getDenom(f)) )
      case Times(lst) => lst.foldLeft(1)( (acc, f) => acc * getDenom(f) )
      case Divides(List(a, IntLit(i))) => i * getDenom(a)
      case other => 1
    }
    def rmDenom(f: Formula, i: scala.Int): Formula = f match {
      case Plus(lst) => Application(Plus, lst.map(rmDenom(_, i))).setType(Int)
      case Minus(lst) => Application(Minus, lst.map(rmDenom(_, i))).setType(Int)
      case Times(lst) => 
        val init = (Nil: List[Formula], i)
        val (lst2, csts) = lst.foldLeft(init)( (acc, f) => rmDenom(f, acc._2) match {
          case Times(IntLit(i) :: xs) => (xs::: acc._1, i)
          case other => (other :: acc._1, 1)
        })
        if (csts == 1) Application(Times, lst2.reverse).setType(Int)
        else Application(Times, IntLit(csts) :: lst2.reverse).setType(Int)
      case Divides(List(a, IntLit(i2))) =>
        assert(i % i2 == 0, "simplifyInt: not divisible by denominator")
        val m = i / i2
        if (m == 1) a else Times(IntLit(m), a)
      case other => Times(IntLit(i), other)
    }
    def removeDiv(lhs: Formula, rhs: Formula): (Formula, Formula) = {
      val d = lcm(getDenom(lhs), getDenom(rhs))
      if (d == 1 || d == 0) lhs -> rhs
      else {
        val l2 = rmDenom(lhs, d)
        val r2 = rmDenom(rhs, d)
        if (d >= 0) l2 -> r2
        else r2 -> l2
      }
    }
    def fct(f: Formula): Formula = f match {
      case Minus(List(x, IntLit(i))) =>
        fct(Plus(x , IntLit(-i)))
      case Plus(lst) =>
        val init = (Nil: List[Formula], 0)
        val (lst2, csts) = lst.foldLeft( init )( (acc, f) => f match {
          case Plus(l2) => (l2 ::: acc._1, acc._2)
          case IntLit(i) => (acc._1, acc._2 + i)
          case other => (other::acc._1, acc._2)
        })
        if (lst2.isEmpty) {
          IntLit(csts)
        } else if (csts == 0) {
          Application(Plus, lst2.reverse).setType(Int)
        } else {
          Application(Plus, (IntLit(csts) :: lst2).reverse).setType(Int)
        }
      case Times(lst) =>
        val init = (Nil: List[Formula], 1)
        val (lst2, csts) = lst.foldLeft( init )( (acc, f) => f match {
          case Times(l2) => (l2 ::: acc._1, acc._2)
          case IntLit(i) => (acc._1, acc._2 * i)
          case other => (other::acc._1, acc._2)
        })
        if (lst2.isEmpty) {
          IntLit(csts)
        } else if (csts == 0) {
          IntLit(0)
        } else if (csts == 1) {
          Application(Times, lst2.reverse).setType(Int)
        } else {
          Application(Times, (IntLit(csts) :: lst2).reverse).setType(Int)
        }
      case Divides(List(IntLit(i1), IntLit(i2))) if i1 % i2 == 0 => IntLit(i1/i2)
      case Divides(List(a, IntLit(1))) => a
      case Divides(List(a, b)) if a == b => IntLit(1)
      case Eq(List(a, b)) if a.tpe == Int =>
        removeDiv(a, b) match {
          case (IntLit(i1), IntLit(i2)) =>
            if (i1 == i2) True()
            else False()
          case (a2, b2) =>
            if (a2 == b2) True()
            else Eq(a2, b2)
        }
      case Lt(List(a, b)) =>
        removeDiv(a, b) match {
          case (IntLit(i1), IntLit(i2)) =>
            if (i1 < i2) True()
            else False()
          case (a2, b2) =>
            if (a2 == b2) False()
            else Lt(a2, b2)
        }
      case other =>
        other
    }
    FormulaUtils.map(fct, f)
  }
  
  def simplifyBool(f: Formula): Formula = {
    def fct(f: Formula) = f match {
      case Or(lst) =>
        val lst2 = lst.filterNot(_ == False())
        if (lst2.exists(_ == True())) True()
        else if (lst2.isEmpty) False()
        else Application(Or, lst2).setType(Bool)
      case And(lst) =>
        val lst2 = lst.filterNot(_ == True())
        if (lst2.exists(_ == False())) False()
        else if (lst2.isEmpty) True()
        else Application(And, lst2).setType(Bool)
      case Not(List(Literal(b: Boolean))) =>
        Literal(!b)
      case other =>
        other
    }
    FormulaUtils.map(fct, f)
  }

  def simplify(f: Formula): Formula = {
    val f1 = normalize(f)
    val f2 = FormulaUtils.flatten(f1)
    val f3 = simplifyInt(f2)
    val f4 = simplifyBool(f3)
    val f5 = simplifyQuantifiers(f4)
    f5
  }


}
